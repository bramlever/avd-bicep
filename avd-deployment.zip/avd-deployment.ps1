﻿param (
    [string]$hostPoolName,
    [string]$registrationInfoToken
)

# Installeer AVD agent
Start-Process msiexec.exe -ArgumentList "/i https://aka.ms/avdagent /quiet /norestart" -Wait

# Registreer VM
$regPath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent"
Set-ItemProperty -Path $regPath -Name "RegistrationToken" -Value $registrationInfoToken
Restart-Service RDAgent