﻿param (
    [string]$hostPoolName,
    [string]$keyVaultName,
    [string]$secretName
)

# Logging starten
$logPath = "C:\AVD-DSC-Log.txt"
"Script gestart op $(Get-Date)" | Out-File -FilePath $logPath

# Stap 1: Haal token op uit Key Vault via Managed Identity
try {
    "Token ophalen uit Key Vault gestart" | Out-File -FilePath $logPath -Append

    $kvUri = "https://$keyVaultName.vault.azure.net"
    $accessToken = (Invoke-RestMethod -Uri "http://169.254.169.254/metadata/identity/oauth2/token?resource=https://vault.azure.net" `
        -Method GET `
        -Headers @{Metadata="true"}).access_token

    $secretUri = "$kvUri/secrets/$secretName?api-version=7.3"
    $registrationInfoToken = (Invoke-RestMethod -Uri $secretUri -Headers @{Authorization = "Bearer $accessToken"}).value

    "Token succesvol opgehaald uit Key Vault" | Out-File -FilePath $logPath -Append
} catch {
    "Fout bij ophalen van token uit Key Vault: $_" | Out-File -FilePath $logPath -Append
    exit 1
}

# Stap 2: Installeer AVD-agent
try {
    "AVD-agent installatie gestart" | Out-File -FilePath $logPath -Append
    Start-Process msiexec.exe -ArgumentList "/i https://aka.ms/avdagent /quiet /norestart" -Wait
    "AVD-agent installatie voltooid" | Out-File -FilePath $logPath -Append
} catch {
    "Fout bij installatie van AVD-agent: $_" | Out-File -FilePath $logPath -Append
    exit 1
}

# Stap 3: Controleer of de service draait
try {
    $service = Get-Service -Name RDAgent -ErrorAction SilentlyContinue
    if ($null -eq $service) {
        "RDAgent service niet gevonden" | Out-File -FilePath $logPath -Append
    } elseif ($service.Status -ne 'Running') {
        "RDAgent service wordt gestart..." | Out-File -FilePath $logPath -Append
        Start-Service RDAgent
        Start-Sleep -Seconds 5
        "RDAgent service gestart" | Out-File -FilePath $logPath -Append
    } else {
        "RDAgent service draait al" | Out-File -FilePath $logPath -Append
    }
} catch {
    "Fout bij controleren/starten van RDAgent: $_" | Out-File -FilePath $logPath -Append
    exit 1
}

# Stap 4: Zet token in registry
try {
    $regPath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent"
    if (-not (Test-Path $regPath)) {
        New-Item -Path $regPath -Force | Out-Null
    }
    Set-ItemProperty -Path $regPath -Name "RegistrationToken" -Value $registrationInfoToken
    "Token geplaatst in registry" | Out-File -FilePath $logPath -Append
} catch {
    "Fout bij plaatsen van token in registry: $_" | Out-File -FilePath $logPath -Append
    exit 1
}

# Stap 5: Herstart de service om registratie te triggeren
try {
    Restart-Service RDAgent -Force
    "RDAgent service herstart voor registratie" | Out-File -FilePath $logPath -Append
} catch {
    "Fout bij herstarten van RDAgent: $_" | Out-File -FilePath $logPath -Append
    exit 1
}
