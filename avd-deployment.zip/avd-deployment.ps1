﻿param (
    [string]$hostPoolName,
    [string]$registrationInfoToken
)

# Download en installeer AVD agent
Start-Process msiexec.exe -ArgumentList "/i https://aka.ms/avdagent /quiet /norestart" -Wait

# Zet de token in de registry
$regPath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent"
New-Item -Path $regPath -Force | Out-Null
Set-ItemProperty -Path $regPath -Name "RegistrationToken" -Value $registrationInfoToken

# Herstart de AVD agent service
Restart-Service RDAgent -Force